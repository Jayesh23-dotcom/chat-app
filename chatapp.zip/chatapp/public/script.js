// script.js

// Show loader for 3 seconds before initializing chat
document.addEventListener("DOMContentLoaded", () => {
  const loader = document.getElementById('loader');
  const messagesDiv = document.getElementById('messages');

  // Show the loader for 3 seconds
  setTimeout(() => {
    loader.style.display = 'none'; // Hide loader
    initializeChat(); // Initialize chat functionalities
  }, 3000); // 3 seconds delay
});

// Function to initialize chat
function initializeChat() {
  const socket = io(); // Connect to the Socket.IO server

  // DOM elements
  const messagesDiv = document.getElementById('messages');
  const messageInput = document.getElementById('messageInput');
  const sendButton = document.getElementById('sendButton');
  const fileInput = document.getElementById('fileInput');
  const emojiButton = document.getElementById('emojiButton');
  const emojiPicker = document.getElementById('emojiPicker');
  const typingNotification = document.getElementById('typingNotification');
  let typingTimeout;

  // Load messages from local storage on page load
  loadMessages();

  // Handle receiving messages and typing notifications
  socket.on('message', (data) => {
    if (data.type === 'message') {
      displayMessage(data.content, false); // Display message for others
    } else if (data.type === 'file') {
      displayImage(data.fileName, false); // Display image for others
    }
  });

  // Handle typing notifications
  socket.on('typing', (data) => {
    showTypingNotification(data.isTyping);
  });

  // Send text message on button click
  sendButton.addEventListener('click', () => {
    sendMessage();
  });

  // Send text message on Enter key press
  messageInput.addEventListener('keypress', (event) => {
    if (event.key === 'Enter' && messageInput.value.trim() !== '') {
      sendMessage();
    }
  });

  // Function to send message
  function sendMessage() {
    const message = messageInput.value;
    if (message.trim() !== '') {
      displayMessage(message, true); // Display the sender's message immediately
      socket.emit('message', { type: 'message', content: message }); // Emit the message to others
      storeMessage(message); // Store message in local storage
      messageInput.value = ''; // Clear the input
    }
  }

  // File upload handling
  fileInput.addEventListener('change', () => {
    const file = fileInput.files[0];
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = () => {
        const base64Image = reader.result;
        socket.emit('message', { type: 'file', fileName: base64Image });
        displayImage(base64Image, true); // Display the image immediately for the sender
      };
      reader.readAsDataURL(file);
    }
  });

  // Show typing notification
  messageInput.addEventListener('input', () => {
    clearTimeout(typingTimeout);
    socket.emit('typing', { isTyping: true });

    typingTimeout = setTimeout(() => {
      socket.emit('typing', { isTyping: false });
    }, 1000);
  });

  // Function to display text message
  function displayMessage(message, isSender = false) {
    const messageContainer = document.createElement('div');
    const messageElement = document.createElement('div');
    messageElement.textContent = message;

    messageContainer.classList.add('message-container');

    if (isSender) {
      messageContainer.classList.add('sender-message-container');
      messageElement.classList.add('message-bubble', 'sender-message-bubble');
    } else {
      messageElement.classList.add('message-bubble');
    }

    messageContainer.appendChild(messageElement);
    messagesDiv.appendChild(messageContainer);
    messagesDiv.scrollTop = messagesDiv.scrollHeight;
  }

  // Function to display image
  function displayImage(imageSrc, isSender = false) {
    const messageContainer = document.createElement('div');
    const imageElement = document.createElement('img');
    imageElement.src = imageSrc;
    imageElement.classList.add(isSender ? 'sender-image' : 'blurred-image');

    messageContainer.classList.add('message-container');

    if (!isSender) {
      // Add click event to clear the blur and download
      imageElement.addEventListener('click', () => {
        imageElement.classList.remove('blurred-image');
        imageElement.classList.add('unblurred-image');
        // Create a link to download the image
        const link = document.createElement('a');
        link.href = imageSrc;
        link.download = 'downloaded-image.png';
        link.click();
      });
    }

    messageContainer.appendChild(imageElement);
    messagesDiv.appendChild(messageContainer);
    messagesDiv.scrollTop = messagesDiv.scrollHeight;
  }

  // Function to show typing notification
  function showTypingNotification(isTyping) {
    typingNotification.textContent = isTyping ? 'Typing...' : '';
  }

  // Emoji picker functionality
  emojiButton.addEventListener('click', () => {
    emojiPicker.classList.toggle('visible');
  });

  // Add emoji to input
  emojiPicker.addEventListener('click', (event) => {
    if (event.target.tagName === 'BUTTON') {
      const emoji = event.target.textContent;
      messageInput.value += emoji;
      emojiPicker.classList.remove('visible');
    }
  });

  // Add emojis to the emoji picker
  const emojis = ['😀', '😁', '😂', '🤣', '😃', '😄', '😅', '😆', '😉', '😊'];
  emojis.forEach((emoji) => {
    const emojiButton = document.createElement('button');
    emojiButton.textContent = emoji;
    emojiPicker.appendChild(emojiButton);
  });

  // Store message in local storage
  function storeMessage(message) {
    let messages = JSON.parse(localStorage.getItem("chatMessages")) || [];
    messages.push(message);
    localStorage.setItem("chatMessages", JSON.stringify(messages));
  }

  // Load messages from local storage
  function loadMessages() {
    const messages = JSON.parse(localStorage.getItem("chatMessages")) || [];
    messages.forEach(message => {
      displayMessage(message, false);
    });
  }
}
